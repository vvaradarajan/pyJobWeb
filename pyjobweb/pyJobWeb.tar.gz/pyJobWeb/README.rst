===============================
pyJobWeb
===============================


.. image:: https://img.shields.io/pypi/v/pyjobweb.svg
        :target: https://pypi.python.org/pypi/pyjobweb

.. image:: https://img.shields.io/travis/vvaradarajan/pyjobweb.svg
        :target: https://travis-ci.org/vvaradarajan/pyjobweb

.. image:: https://readthedocs.org/projects/pyjobweb/badge/?version=latest
        :target: https://pyjobweb.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status

.. image:: https://pyup.io/repos/github/vvaradarajan/pyjobweb/shield.svg
     :target: https://pyup.io/repos/github/vvaradarajan/pyjobweb/
     :alt: Updates


Shows status of concurrent job execution in python/flask webapp


* Free software: Apache Software License 2.0
* Documentation: https://pyjobweb.readthedocs.io.


Features
--------

* TODO

Credits
---------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage

