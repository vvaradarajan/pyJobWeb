=====
Usage
=====

To use pyJobWeb in a project::

    import pyjobweb
