/* Add a controller for the menu bar*/
app.controller('headerCtrl',  function($scope) {
    $scope.contact = 'vsvconsult@gmail.com';
});
